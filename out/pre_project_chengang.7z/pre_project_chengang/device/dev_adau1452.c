#include "dev_adau1452.h"
#include "chengang_IC_1_PARAM.h"


void adau1452_enter_spi_ctrl(void)
{
	spi2_init(MODE4, SPI_BaudRatePrescaler_4);	//16Mhz clk

	SPI2_CS_LOW();
	spi2_transfer_byte(DummyByte);
	SPI2_CS_HIGH();

	SPI2_CS_LOW();
	spi2_transfer_byte(DummyByte);
	SPI2_CS_HIGH();

	SPI2_CS_LOW();
	spi2_transfer_byte(DummyByte);
	SPI2_CS_HIGH();
}

void adau1452_read_bytes(uint8_t dev_addr, uint16_t reg_addr, uint16_t length, uint8_t *buffer)
{
	SPI2_CS_LOW();
	spi2_transfer_byte(dev_addr | SPI_RD);
	spi2_transfer_byte((uint8_t)(reg_addr>>8));
	spi2_transfer_byte((uint8_t)reg_addr);
	for(uint16_t i=0;i<length;i++)
	{
		*(buffer + i) = spi2_transfer_byte(DummyByte);
	}
	SPI2_CS_HIGH();
}

void adau1452_write_bytes(uint8_t dev_addr, uint16_t reg_addr, uint16_t length, const uint8_t *buffer)
{
	SPI2_CS_LOW();
	spi2_transfer_byte(dev_addr | SPI_WR);
	spi2_transfer_byte((uint8_t)(reg_addr>>8));
	spi2_transfer_byte((uint8_t)reg_addr);
	for(uint16_t i=0;i<length;i++)
	{
		spi2_transfer_byte(*(buffer + i));
	}
	SPI2_CS_HIGH();
}

void debug_write(uint8_t dev_addr, uint16_t reg_addr, uint16_t length, const uint8_t *buffer)
{
	uint8_t debug[2];
	adau1452_write_bytes(dev_addr, reg_addr, length, buffer);
	adau1452_read_bytes(dev_addr, reg_addr, length, debug);
	rt_kprintf("rd 0x%04X:0x%02X%02X\r\n", reg_addr, debug[0], debug[1]);
}

void SIGMA_WRITE_REGISTER_BLOCK(uint8_t dev_addr, uint16_t reg_addr, uint16_t length, const uint8_t *buffer)
{
	adau1452_write_bytes(dev_addr, reg_addr, length, buffer);
}

void SIGMA_WRITE_DELAY(uint8_t dev_addr, uint16_t length, const uint8_t *buffer)
{
	for(uint16_t i=0;i<length;i++)
		spi2_transfer_byte(DummyByte);
}

//��ȫ���أ�ÿ�����д��5����
void SIGMA_SAFELOAD_WRITE_REGISTER_BLOCK(uint8_t dev_addr, uint16_t reg_addr, uint16_t length, const uint8_t *buffer)
{
	uint8_t target_addr[4];
	uint8_t dat_len[4];

	//safeloadÿ�����д��5��word
	if(length > 20)	
	{
		rt_kprintf("safeload dat len too long.\r\n");
		return;
	}

	//��д�����ݵ�safeload���ݶ�
	adau1452_write_bytes(dev_addr, MOD_SAFELOADMODULE_DATA_SAFELOAD0_ADDR, length, buffer);

	//д��Ŀ���ַ��safeloadĿ���ַ��
	target_addr[0] = 0x00;
	target_addr[1] = 0x00;
	target_addr[2] = (uint8_t)(reg_addr>>8);
	target_addr[3] = (uint8_t)reg_addr;
	adau1452_write_bytes(dev_addr, (MOD_SAFELOADMODULE_DATA_SAFELOAD0_ADDR+5), 4, target_addr);

	//д�����ݳ��ȵ�safeload���ݳ��ȶ�
	dat_len[0] = 0x00;
	dat_len[1] = 0x00;
	dat_len[2] = (uint8_t)(length>>8);
	dat_len[3] = (uint8_t)length;
	adau1452_write_bytes(dev_addr, (MOD_SAFELOADMODULE_DATA_SAFELOAD0_ADDR+6), 4, dat_len);
}


