#ifndef _DEV_ADAU1452_H_
#define _DEV_ADAU1452_H_

#include "stm32f10x.h"
#include "drv_spi.h"
#include "rtthread.h"

typedef const uint8_t ADI_REG_TYPE;	

#define ADAU1452_ADDR		0x00

void adau1452_enter_spi_ctrl(void);
void adau1452_read_bytes(uint8_t dev_addr, uint16_t reg_addr, uint16_t length, uint8_t *buffer);
void adau1452_write_bytes(uint8_t dev_addr, uint16_t reg_addr, uint16_t length, const uint8_t *buffer);
void debug_write(uint8_t dev_addr, uint16_t reg_addr, uint16_t length, const uint8_t *buffer);


void SIGMA_WRITE_REGISTER_BLOCK(uint8_t dev_addr, uint16_t reg_addr, uint16_t length, const uint8_t *buffer);
void SIGMA_WRITE_DELAY(uint8_t dev_addr, uint16_t length, const uint8_t *buffer);
void SIGMA_SAFELOAD_WRITE_REGISTER_BLOCK(uint8_t dev_addr, uint16_t reg_addr, uint16_t length, const uint8_t *buffer);




#endif



