#include "dev_led.h"

static mini_device led_dev;	//�趨��Ϊʵ�����ͣ�������ָ�룬����ʵ���ڴ����ڴ洢�ص���ַ

static void led_gpio_cfg(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;

	//led0 configure
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);	
	
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4;		
	GPIO_Init(GPIOB, &GPIO_InitStructure);
	GPIOB->BSRR = GPIO_Pin_4;//��λ��Ϩ��LED0

	//led1 configure
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_5;		
	GPIO_Init(GPIOB, &GPIO_InitStructure);
	GPIOB->BSRR = GPIO_Pin_5;//��λ��Ϩ��LED1
}

static bool led_init(void *args)
{
	led_gpio_cfg();
	
	return true;
}

static bool led_control(int cmd, void *args)
{
	led_ctrl_t led_ctrl_struct = (led_ctrl_t)args;

	switch(led_ctrl_struct->led_index)
	{
		case LED0:
			switch(cmd)
			{
				case TRUN_ON:
					GPIOB->BRR = GPIO_Pin_4;
				break;

				case TRUN_OFF:
					GPIOB->BSRR = GPIO_Pin_4;
				break;
			}
		break;

		case LED1:
			switch(cmd)
			{
				case TRUN_ON:
					GPIOB->BRR = GPIO_Pin_5;
				break;

				case TRUN_OFF:
					GPIOB->BSRR = GPIO_Pin_5;
				break;
			}
		break;
	}
	
	return true;
}

static int led_read_status(void *args, int size)
{
	int led_status = 0;
	led_ctrl_t led_ctrl_struct = (led_ctrl_t)args;

	switch(led_ctrl_struct->led_index)
	{
		case LED0:
			led_status = GPIO_ReadOutputDataBit(GPIOB, GPIO_Pin_4);
		break;

		case LED1:
			led_status = GPIO_ReadOutputDataBit(GPIOB, GPIO_Pin_5);
		break;
	}

	return led_status;
}

static mini_device_ops ops =	//�趨��Ϊʵ�����ͣ�������ָ��
{
	.init = led_init,
	.control = led_control,
	.read = led_read_status,
};

static void led_register(void)
{
    led_dev.name = "led";
    led_dev.dops = &ops; 
    if(mini_device_register(&led_dev) == true)
    	led_dev.dops->init(NULL);
}

device_initcall(led_register);


