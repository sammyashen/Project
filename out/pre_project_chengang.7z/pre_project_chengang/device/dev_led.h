#ifndef _DEV_LED_H_
#define _DEV_LED_H_

#include "stm32f10x.h"
#include "init.h"
#include "device.h"

typedef enum{
	LED0 = 0,
	LED1,
}led_index_e;

typedef enum{
	TRUN_ON = 0,
	TRUN_OFF,
	TRUN_BLINK,
	TRUN_BREATH,
}led_cmd_e;

typedef struct{
	uint8_t led_index;
}led_ctrl, *led_ctrl_t;

#endif


