#include "drv_systick.h"

static void set_sysclk_to_64Mhz(void)
{
	__IO ErrorStatus HSIStartUpStatus = SUCCESS;

	/* SYSCLK, HCLK, PCLK2 and PCLK1 configuration -----------------------------*/   
	/* RCC system reset(for debug purpose) */
	RCC_DeInit();

	/* Enable HSI */
	RCC_HSICmd(ENABLE);

	/* Wait till HSI is ready */
	if((RCC->CR & RCC_CR_HSIRDY) == RCC_CR_HSIRDY)
		HSIStartUpStatus = SUCCESS;
	else
		HSIStartUpStatus = ERROR;

	if(HSIStartUpStatus == SUCCESS)
	{
		/* Enable Prefetch Buffer */
		FLASH_PrefetchBufferCmd(FLASH_PrefetchBuffer_Enable);

		/* Flash 2 wait state */
		FLASH_SetLatency(FLASH_Latency_2);

		/* HCLK = SYSCLK */
		RCC_HCLKConfig(RCC_SYSCLK_Div1); 

		/* PCLK2 = HCLK */
		RCC_PCLK2Config(RCC_HCLK_Div1); 

		/* PCLK1 = HCLK/2 */
		RCC_PCLK1Config(RCC_HCLK_Div2);

		/* PLLCLK = 8MHz / 2 * 16 = 64 MHz */
		RCC_PLLConfig(RCC_PLLSource_HSI_Div2, RCC_PLLMul_16);

		/* Enable PLL */ 
		RCC_PLLCmd(ENABLE);

		/* Wait till PLL is ready */
		while (RCC_GetFlagStatus(RCC_FLAG_PLLRDY) == RESET)
		{
		}

		/* Select PLL as system clock source */
		RCC_SYSCLKConfig(RCC_SYSCLKSource_PLLCLK);

		/* Wait till PLL is used as system clock source */
		while(RCC_GetSYSCLKSource() != 0x08)
		{
		}
	}
	else
	{ /* If HSI fails to start-up, the application will have wrong clock configuration.
	   User can add here some code to deal with this error */    

		/* Go to infinite loop */
		while (1)
		{
		}
	}
}

static void systick_init(void)
{
   	set_sysclk_to_64Mhz();
	RCC_ClockSecuritySystemCmd(ENABLE);
}

sys_initcall(systick_init);



