#include "drv_spi.h"

void spi2_init(SPI_ModeTypedef SPI_Mode, u16 SPI_BaudRatePrescalerValue)
{
	SPI_InitTypeDef SPI_InitStructure;
    GPIO_InitTypeDef GPIO_InitStructure;
    
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB | RCC_APB2Periph_GPIOC, ENABLE);
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_SPI2, ENABLE);
    
    /* SPI1(master) GPIO configuration */
	/* Configure SCK(PB.13),MISO(PB.14),MOSI(PB.15) as alternate function push-pull */
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13 | GPIO_Pin_14 | GPIO_Pin_15;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
  	GPIO_Init(GPIOB, &GPIO_InitStructure);
	/* Configure NSS(PC.06) as output push-pull */
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_Init(GPIOC, &GPIO_InitStructure);
    
    SPI2_CS_HIGH();
    
	SPI_I2S_DeInit(SPI2);
	/* SPI1 configuration */
	switch (SPI_Mode)
	{
		case MODE1:
			SPI_InitStructure.SPI_CPOL = SPI_CPOL_Low;			  //ʱ�����յ�
			SPI_InitStructure.SPI_CPHA = SPI_CPHA_1Edge;		  //���ݲ����ڵ�һ��ʱ����
			break;
		case MODE2:
			SPI_InitStructure.SPI_CPOL = SPI_CPOL_Low;			  //ʱ�����յ�
			SPI_InitStructure.SPI_CPHA = SPI_CPHA_2Edge;		  //���ݲ����ڵڶ���ʱ����
			break;
		case MODE3:
			SPI_InitStructure.SPI_CPOL = SPI_CPOL_High;			  //ʱ�����ո�
			SPI_InitStructure.SPI_CPHA = SPI_CPHA_1Edge;		  //���ݲ����ڵ�һ��ʱ����
			break;
		case MODE4:
			SPI_InitStructure.SPI_CPOL = SPI_CPOL_High;			  //ʱ�����ո�
			SPI_InitStructure.SPI_CPHA = SPI_CPHA_2Edge;		  //���ݲ����ڵڶ���ʱ����
			break;
		default:
			break;		
	}
	SPI_InitStructure.SPI_Direction = SPI_Direction_2Lines_FullDuplex;  //SPI����Ϊ˫��˫��ȫ˫��
//	SPI_InitStructure.SPI_Direction = SPI_Direction_1Line_Tx;
	SPI_InitStructure.SPI_Mode = SPI_Mode_Master;                       //����Ϊ��SPI 
	SPI_InitStructure.SPI_DataSize = SPI_DataSize_8b;	                //SPI���ͽ���8λ֡�ṹ
//	SPI_InitStructure.SPI_NSS = SPI_NSS_Hard;		                    //Ӳ��NSSģʽ
	SPI_InitStructure.SPI_NSS = SPI_NSS_Soft;		                    //�ڲ�NSS��SSIλ����
	SPI_InitStructure.SPI_BaudRatePrescaler = SPI_BaudRatePrescalerValue;	  //������Ԥ��ƵֵΪ4
	SPI_InitStructure.SPI_FirstBit = SPI_FirstBit_MSB;                        //���ݴ����MSBλ��ʼ
	SPI_InitStructure.SPI_CRCPolynomial = 7;
	SPI_Init(SPI2, &SPI_InitStructure);

//	SPI_SSOutputCmd(SPI2, ENABLE);	                                          //Ӳ��NSSģʽ�£�ʹ�������NSS������͵�ƽ
	/* Enable SPI2 */
	SPI_Cmd(SPI2, ENABLE);
}

uint8_t spi2_transfer_byte(uint8_t byte)
{
    /* Loop while DR register in not emplty */
    while (SPI_I2S_GetFlagStatus(SPI2, SPI_I2S_FLAG_TXE) == RESET);
    /* Send byte through the SPI1 peripheral */
    SPI_I2S_SendData(SPI2, byte);
    /* Wait to receive a byte */
    while (SPI_I2S_GetFlagStatus(SPI2, SPI_I2S_FLAG_RXNE) == RESET);
    /* Return the byte read from the SPI bus */
    return SPI_I2S_ReceiveData(SPI2);  
}

