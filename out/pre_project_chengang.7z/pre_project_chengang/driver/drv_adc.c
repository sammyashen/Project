#include "drv_adc.h"

static mini_device adc_dev;
__IO uint16_t ADC1_SampleBuffer[10];						 

static void ADC1_PeriphConfig(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;

	RCC_ADCCLKConfig(RCC_PCLK2_Div6);		//ADC Clock = sysclk / 6.
	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1, ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_ADC1, ENABLE);

	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_2 | GPIO_Pin_3;		
    GPIO_Init(GPIOA, &GPIO_InitStructure);
}

static void ADC1_RegConfig(void)
{
	uint8_t i;
	uint16_t temp = 0x0001;
	uint8_t rank = 1;
	ADC_InitTypeDef ADC_InitStructure;
	DMA_InitTypeDef DMA_InitStructure;

	ADC_DeInit(ADC1);  
	/* ADC configuration */
	ADC_InitStructure.ADC_Mode = ADC_Mode_Independent;							
	ADC_InitStructure.ADC_ScanConvMode = ENABLE;								
	ADC_InitStructure.ADC_ContinuousConvMode = ENABLE;							
	ADC_InitStructure.ADC_ExternalTrigConv = ADC_ExternalTrigConv_None;
	ADC_InitStructure.ADC_DataAlign = ADC_DataAlign_Right;	 				
	ADC_InitStructure.ADC_NbrOfChannel = ADC1_NbrOfChannel;		 				
	ADC_Init(ADC1, &ADC_InitStructure);				

	/* ADC regular channel configuration */
	for (i = 0;i < 16;i++)
	{
		if (ADC1_SampleChannel & temp)
		{
			ADC_RegularChannelConfig(ADC1, i, rank++, ADC1_SampleTime);	
		}
		temp <<= 1;	
	}
	
	/* Enable ADC */
	ADC_Cmd(ADC1, ENABLE);	
	/* Enable ADC reset calibaration register */   
	ADC_ResetCalibration(ADC1);		 											
	/* Check the end of ADC reset calibration register */
	while(ADC_GetResetCalibrationStatus(ADC1));	  
	/* enable Adc calibration bypass. */
//	ADC_SetBypassCalibration(ADC1, DISABLE);
	/* Start ADC calibaration */
	ADC_StartCalibration(ADC1);													
	/* Check the end of ADC calibration */
	while(ADC_GetCalibrationStatus(ADC1));	  		

	/* DMA1_channel1 configuration */
	DMA_DeInit(DMA1_Channel1);	   												
	DMA_InitStructure.DMA_PeripheralBaseAddr 				= (u32)&ADC1->DR;//ADC1_DAT_Address;					
	DMA_InitStructure.DMA_MemoryBaseAddr 					= (u32)ADC1_SampleBuffer;				
	DMA_InitStructure.DMA_DIR 								= DMA_DIR_PeripheralSRC;							
	DMA_InitStructure.DMA_BufferSize 						= ADC1_SampleBufferSize;					
	DMA_InitStructure.DMA_PeripheralInc 					= DMA_PeripheralInc_Disable;		
	DMA_InitStructure.DMA_MemoryInc 						= DMA_MemoryInc_Enable;						
	DMA_InitStructure.DMA_PeripheralDataSize 				= DMA_PeripheralDataSize_HalfWord;	
	DMA_InitStructure.DMA_MemoryDataSize 					= DMA_MemoryDataSize_HalfWord;	   		
	DMA_InitStructure.DMA_Mode 								= DMA_Mode_Circular;								
	DMA_InitStructure.DMA_Priority							= DMA_Priority_High;							
	DMA_InitStructure.DMA_M2M			 					= DMA_M2M_Disable;			 					
	DMA_Init(DMA1_Channel1, &DMA_InitStructure);	   							
//	DMA_ITConfig(DMA1_Channel1, DMA_IT_TC, ENABLE);
	/* Enable DMA channel1 */
	DMA_Cmd(DMA1_Channel1, ENABLE);			                                    
	ADC_DMACmd(ADC1, ENABLE);                                                   
	ADC_SoftwareStartConvCmd(ADC1, ENABLE);                                     
}

static void ADC1_Init(void)
{
    ADC1_PeriphConfig();
    ADC1_RegConfig();
}

static uint16_t ADC_GetSample(uint8_t type)
{
    uint16_t temp = 0;
    switch (type)
    {
        case RW1_SAMPLE:
            temp = ADC1_SampleBuffer[0];
            break;
		
        case RW2_SAMPLE:
            temp = ADC1_SampleBuffer[1];
            break;
		
        case RW3_SAMPLE:
            temp = ADC1_SampleBuffer[2];
			break;
		
		case RW4_SAMPLE:
			temp = ADC1_SampleBuffer[3];
			break;
			
        default:
            break;
    }
    return temp;
}

static bool adc_init(void *args)
{
	ADC1_Init();
	
	return true;
}

static int adc_read(void *args, int size)
{
	int val;
	adc_ctrl_t adc_ctrl_struct = (adc_ctrl_t)args;

	val = ADC_GetSample(adc_ctrl_struct->chn_index);

	return val;
}

static mini_device_ops ops =	//�趨��Ϊʵ�����ͣ�������ָ��
{
	.init = adc_init,
	.read = adc_read,
};

static void adc_register(void)
{
    adc_dev.name = "adc";
    adc_dev.dops = &ops; 
    if(mini_device_register(&adc_dev) == true)
    	adc_dev.dops->init(NULL);
}

device_initcall(adc_register);



