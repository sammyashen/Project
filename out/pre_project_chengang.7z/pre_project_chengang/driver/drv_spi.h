#ifndef _DRV_SPI_H_
#define _DRV_SPI_H_

#include "stm32f10x.h"

#define SPI_RD	0x01
#define SPI_WR	0x00

#define	SPI2_CS_LOW()     GPIO_ResetBits(GPIOC, GPIO_Pin_6)
#define SPI2_CS_HIGH()    GPIO_SetBits(GPIOC, GPIO_Pin_6)
#define DummyByte    0xFF

typedef enum
{
	MODE1 = 0x01,	 //CPOL = 0,CPHA = 0
	MODE2,			 //CPOL = 0,CPHA = 1
	MODE3,			 //CPOL = 1,CPHA = 0
	MODE4,			 //CPOL = 1,CPHA = 1
}SPI_ModeTypedef;

void spi2_init(SPI_ModeTypedef SPI_Mode, u16 SPI_BaudRatePrescalerValue);
uint8_t spi2_transfer_byte(uint8_t byte);


#endif


