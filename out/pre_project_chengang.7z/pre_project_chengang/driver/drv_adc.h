#ifndef __DRV_adc_H
#define __DRV_adc_H

#include "stm32f10x.h"
#include "init.h"
#include "device.h"

#define    ADC1_DAT_Address	            ((u32)0x4001244C)
#define    ADC1_SampleChannel			0x000F		//ADC1_ch3��2��1��0
#define    ADC1_SampleTime				ADC_SampleTime_55Cycles5
#define    ADC1_SampleTimes				1
#define    ADC1_NbrOfChannel            4
#define    ADC1_SampleBufferSize        (ADC1_NbrOfChannel * ADC1_SampleTimes)

#define    RW1_SAMPLE               	0x01
#define    RW2_SAMPLE                	0x02
#define    RW3_SAMPLE               	0x03
#define	   RW4_SAMPLE					0x04

typedef struct{
	uint16_t chn_index;
}adc_ctrl, *adc_ctrl_t;



#endif


