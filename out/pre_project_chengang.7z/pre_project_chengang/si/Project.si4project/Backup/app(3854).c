#include "rtthread.h"

#include "drv_uart.h"
#include "drv_adc.h"
#include "drv_i2c.h"
#include "drv_key.h"

#include "dev_led.h"
#include "dev_adau1452.h"

#include "dispatch.h"
#include "chart.h"

#include "adau1452_IC_1.h"
#include "adau1452_IC_1_PARAM.h"
#include "adau1452_IC_1_REG.h"
#include "defines.h"

void sigma_default_set(void)
{
	ErrorStatus err = SUCCESS;

	err = adau1452_write_bytes( DEVICE_ADDR_IC_1, REG_SOFT_RESET_IC_1_ADDR, REG_SOFT_RESET_IC_1_BYTE, R0_SOFT_RESET_IC_1_Default );
	err = adau1452_write_bytes( DEVICE_ADDR_IC_1, REG_SOFT_RESET_IC_1_ADDR, REG_SOFT_RESET_IC_1_BYTE, R1_SOFT_RESET_IC_1_Default );
	rt_thread_mdelay(5);
	if(err != SUCCESS)	rt_kprintf("0\r\n");
	err = adau1452_write_bytes( DEVICE_ADDR_IC_1, REG_HIBERNATE_IC_1_ADDR, REG_HIBERNATE_IC_1_BYTE, R3_HIBERNATE_IC_1_Default );
	err	= adau1452_write_bytes( DEVICE_ADDR_IC_1, REG_HIBERNATE_IC_1_ADDR, REG_HIBERNATE_IC_1_BYTE, R4_HIBERNATE_IC_1_Default );
	if(err != SUCCESS)	rt_kprintf("1\r\n");
	err	= adau1452_write_bytes( DEVICE_ADDR_IC_1, REG_KILL_CORE_IC_1_ADDR, REG_KILL_CORE_IC_1_BYTE, R6_KILL_CORE_IC_1_Default );
	err	= adau1452_write_bytes( DEVICE_ADDR_IC_1, REG_KILL_CORE_IC_1_ADDR, REG_KILL_CORE_IC_1_BYTE, R7_KILL_CORE_IC_1_Default );
	if(err != SUCCESS)	rt_kprintf("2\r\n");
	err	= adau1452_write_bytes( DEVICE_ADDR_IC_1, REG_PLL_ENABLE_IC_1_ADDR, REG_PLL_ENABLE_IC_1_BYTE, R8_PLL_ENABLE_IC_1_Default );
	if(err != SUCCESS)	rt_kprintf("3\r\n");
	err	= adau1452_write_bytes( DEVICE_ADDR_IC_1, REG_PLL_CTRL0_IC_1_ADDR, REG_PLL_CTRL0_IC_1_BYTE, R9_PLL_CTRL0_IC_1_Default );
	if(err != SUCCESS)	rt_kprintf("4\r\n");
	err	= adau1452_write_bytes( DEVICE_ADDR_IC_1, REG_PLL_CTRL1_IC_1_ADDR, REG_PLL_CTRL1_IC_1_BYTE, R10_PLL_CTRL1_IC_1_Default );
	if(err != SUCCESS)	rt_kprintf("5\r\n");
	err	= adau1452_write_bytes( DEVICE_ADDR_IC_1, REG_PLL_CLK_SRC_IC_1_ADDR, REG_PLL_CLK_SRC_IC_1_BYTE, R11_PLL_CLK_SRC_IC_1_Default );
	if(err != SUCCESS)	rt_kprintf("6\r\n");
	err	= adau1452_write_bytes( DEVICE_ADDR_IC_1, REG_MCLK_OUT_IC_1_ADDR, REG_MCLK_OUT_IC_1_BYTE, R12_MCLK_OUT_IC_1_Default );
	if(err != SUCCESS)	rt_kprintf("7\r\n");
	err	= adau1452_write_bytes( DEVICE_ADDR_IC_1, REG_PLL_ENABLE_IC_1_ADDR, REG_PLL_ENABLE_IC_1_BYTE, R13_PLL_ENABLE_IC_1_Default );
	if(err != SUCCESS)	rt_kprintf("8\r\n");
	//�ر�ע��˴���Դ�Ĵ��������ã���Ҫ����Щ���ӳ�
	rt_thread_mdelay(5);
	err	= adau1452_write_bytes( DEVICE_ADDR_IC_1, REG_POWER_ENABLE0_IC_1_ADDR, REG_POWER_ENABLE0_IC_1_BYTE, R15_POWER_ENABLE0_IC_1_Default );
	if(err != SUCCESS)	rt_kprintf("9\r\n");
	rt_thread_mdelay(5);
	err	= adau1452_write_bytes( DEVICE_ADDR_IC_1, REG_POWER_ENABLE1_IC_1_ADDR, REG_POWER_ENABLE1_IC_1_BYTE, R16_POWER_ENABLE1_IC_1_Default );
	if(err != SUCCESS)	rt_kprintf("10\r\n");
	rt_thread_mdelay(5);
	err	= adau1452_write_bytes( DEVICE_ADDR_IC_1, REG_MP5_MODE_IC_1_ADDR, REG_MP5_MODE_IC_1_BYTE, R17_MP5_MODE_IC_1_Default );
	if(err != SUCCESS)	rt_kprintf("11\r\n");
	err	= adau1452_write_bytes( DEVICE_ADDR_IC_1, REG_MP6_MODE_IC_1_ADDR, REG_MP6_MODE_IC_1_BYTE, R18_MP6_MODE_IC_1_Default );
	if(err != SUCCESS)	rt_kprintf("12\r\n");
	err	= adau1452_write_bytes( DEVICE_ADDR_IC_1, REG_SOUT_SOURCE0_IC_1_ADDR, REG_SOUT_SOURCE0_IC_1_BYTE, R19_SOUT_SOURCE0_IC_1_Default );
	if(err != SUCCESS)	rt_kprintf("13\r\n");
	err	= adau1452_write_bytes( DEVICE_ADDR_IC_1, REG_SOUT_SOURCE1_IC_1_ADDR, REG_SOUT_SOURCE1_IC_1_BYTE, R20_SOUT_SOURCE1_IC_1_Default );
	if(err != SUCCESS)	rt_kprintf("14\r\n");
	err	= adau1452_write_bytes( DEVICE_ADDR_IC_1, REG_SOUT_SOURCE2_IC_1_ADDR, REG_SOUT_SOURCE2_IC_1_BYTE, R21_SOUT_SOURCE2_IC_1_Default );
	if(err != SUCCESS)	rt_kprintf("15\r\n");
	err	= adau1452_write_bytes( DEVICE_ADDR_IC_1, REG_SOUT_SOURCE3_IC_1_ADDR, REG_SOUT_SOURCE3_IC_1_BYTE, R22_SOUT_SOURCE3_IC_1_Default );
	if(err != SUCCESS)	rt_kprintf("16\r\n");
	err	= adau1452_write_bytes( DEVICE_ADDR_IC_1, REG_SOUT_SOURCE4_IC_1_ADDR, REG_SOUT_SOURCE4_IC_1_BYTE, R23_SOUT_SOURCE4_IC_1_Default );
	if(err != SUCCESS)	rt_kprintf("17\r\n");
	err	= adau1452_write_bytes( DEVICE_ADDR_IC_1, REG_SOUT_SOURCE5_IC_1_ADDR, REG_SOUT_SOURCE5_IC_1_BYTE, R24_SOUT_SOURCE5_IC_1_Default );
	if(err != SUCCESS)	rt_kprintf("18\r\n");
	err	= adau1452_write_bytes( DEVICE_ADDR_IC_1, REG_SOUT_SOURCE6_IC_1_ADDR, REG_SOUT_SOURCE6_IC_1_BYTE, R25_SOUT_SOURCE6_IC_1_Default );
	if(err != SUCCESS)	rt_kprintf("19\r\n");
	err	= adau1452_write_bytes( DEVICE_ADDR_IC_1, REG_SOUT_SOURCE7_IC_1_ADDR, REG_SOUT_SOURCE7_IC_1_BYTE, R26_SOUT_SOURCE7_IC_1_Default );
	if(err != SUCCESS)	rt_kprintf("20\r\n");
	err	= adau1452_write_bytes( DEVICE_ADDR_IC_1, REG_SOUT_SOURCE8_IC_1_ADDR, REG_SOUT_SOURCE8_IC_1_BYTE, R27_SOUT_SOURCE8_IC_1_Default );
	if(err != SUCCESS)	rt_kprintf("21\r\n");
	err	= adau1452_write_bytes( DEVICE_ADDR_IC_1, REG_SOUT_SOURCE9_IC_1_ADDR, REG_SOUT_SOURCE9_IC_1_BYTE, R28_SOUT_SOURCE9_IC_1_Default );
	if(err != SUCCESS)	rt_kprintf("22\r\n");
	err	= adau1452_write_bytes( DEVICE_ADDR_IC_1, REG_SOUT_SOURCE10_IC_1_ADDR, REG_SOUT_SOURCE10_IC_1_BYTE, R29_SOUT_SOURCE10_IC_1_Default );
	if(err != SUCCESS)	rt_kprintf("23\r\n");
	err	= adau1452_write_bytes( DEVICE_ADDR_IC_1, REG_SOUT_SOURCE11_IC_1_ADDR, REG_SOUT_SOURCE11_IC_1_BYTE, R30_SOUT_SOURCE11_IC_1_Default );
	if(err != SUCCESS)	rt_kprintf("24\r\n");
	err	= adau1452_write_bytes( DEVICE_ADDR_IC_1, REG_SOUT_SOURCE12_IC_1_ADDR, REG_SOUT_SOURCE12_IC_1_BYTE, R31_SOUT_SOURCE12_IC_1_Default );
	if(err != SUCCESS)	rt_kprintf("25\r\n");
	err	= adau1452_write_bytes( DEVICE_ADDR_IC_1, REG_SOUT_SOURCE13_IC_1_ADDR, REG_SOUT_SOURCE13_IC_1_BYTE, R32_SOUT_SOURCE13_IC_1_Default );
	if(err != SUCCESS)	rt_kprintf("26\r\n");
	err	= adau1452_write_bytes( DEVICE_ADDR_IC_1, REG_SOUT_SOURCE14_IC_1_ADDR, REG_SOUT_SOURCE14_IC_1_BYTE, R33_SOUT_SOURCE14_IC_1_Default );
	if(err != SUCCESS)	rt_kprintf("27\r\n");
	err	= adau1452_write_bytes( DEVICE_ADDR_IC_1, REG_SOUT_SOURCE15_IC_1_ADDR, REG_SOUT_SOURCE15_IC_1_BYTE, R34_SOUT_SOURCE15_IC_1_Default );
	if(err != SUCCESS)	rt_kprintf("28\r\n");
	err	= adau1452_write_bytes( DEVICE_ADDR_IC_1, REG_SOUT_SOURCE16_IC_1_ADDR, REG_SOUT_SOURCE16_IC_1_BYTE, R35_SOUT_SOURCE16_IC_1_Default );
	if(err != SUCCESS)	rt_kprintf("29\r\n");
	err	= adau1452_write_bytes( DEVICE_ADDR_IC_1, REG_SOUT_SOURCE17_IC_1_ADDR, REG_SOUT_SOURCE17_IC_1_BYTE, R36_SOUT_SOURCE17_IC_1_Default );
	if(err != SUCCESS)	rt_kprintf("30\r\n");
	err	= adau1452_write_bytes( DEVICE_ADDR_IC_1, REG_SOUT_SOURCE18_IC_1_ADDR, REG_SOUT_SOURCE18_IC_1_BYTE, R37_SOUT_SOURCE18_IC_1_Default );
	if(err != SUCCESS)	rt_kprintf("31\r\n");
	err	= adau1452_write_bytes( DEVICE_ADDR_IC_1, REG_SOUT_SOURCE19_IC_1_ADDR, REG_SOUT_SOURCE19_IC_1_BYTE, R38_SOUT_SOURCE19_IC_1_Default );
	if(err != SUCCESS)	rt_kprintf("32\r\n");
	err	= adau1452_write_bytes( DEVICE_ADDR_IC_1, REG_SOUT_SOURCE20_IC_1_ADDR, REG_SOUT_SOURCE20_IC_1_BYTE, R39_SOUT_SOURCE20_IC_1_Default );
	if(err != SUCCESS)	rt_kprintf("33\r\n");
	err	= adau1452_write_bytes( DEVICE_ADDR_IC_1, REG_SOUT_SOURCE21_IC_1_ADDR, REG_SOUT_SOURCE21_IC_1_BYTE, R40_SOUT_SOURCE21_IC_1_Default );
	if(err != SUCCESS)	rt_kprintf("34\r\n");
	err	= adau1452_write_bytes( DEVICE_ADDR_IC_1, REG_SOUT_SOURCE22_IC_1_ADDR, REG_SOUT_SOURCE22_IC_1_BYTE, R41_SOUT_SOURCE22_IC_1_Default );
	if(err != SUCCESS)	rt_kprintf("35\r\n");
	err	= adau1452_write_bytes( DEVICE_ADDR_IC_1, REG_SOUT_SOURCE23_IC_1_ADDR, REG_SOUT_SOURCE23_IC_1_BYTE, R42_SOUT_SOURCE23_IC_1_Default );
	if(err != SUCCESS)	rt_kprintf("36\r\n");
	err	= adau1452_write_bytes( DEVICE_ADDR_IC_1, REG_SERIAL_BYTE_0_0_IC_1_ADDR, REG_SERIAL_BYTE_0_0_IC_1_BYTE, R43_SERIAL_BYTE_0_0_IC_1_Default );
	if(err != SUCCESS)	rt_kprintf("37\r\n");
	err	= adau1452_write_bytes( DEVICE_ADDR_IC_1, REG_SERIAL_BYTE_1_0_IC_1_ADDR, REG_SERIAL_BYTE_1_0_IC_1_BYTE, R44_SERIAL_BYTE_1_0_IC_1_Default );
	if(err != SUCCESS)	rt_kprintf("38\r\n");
	err	= adau1452_write_bytes( DEVICE_ADDR_IC_1, REG_SERIAL_BYTE_2_0_IC_1_ADDR, REG_SERIAL_BYTE_2_0_IC_1_BYTE, R45_SERIAL_BYTE_2_0_IC_1_Default );
	if(err != SUCCESS)	rt_kprintf("39\r\n");
	err	= adau1452_write_bytes( DEVICE_ADDR_IC_1, REG_SERIAL_BYTE_3_0_IC_1_ADDR, REG_SERIAL_BYTE_3_0_IC_1_BYTE, R46_SERIAL_BYTE_3_0_IC_1_Default );
	if(err != SUCCESS)	rt_kprintf("40\r\n");
	err	= adau1452_write_bytes( DEVICE_ADDR_IC_1, REG_SERIAL_BYTE_4_0_IC_1_ADDR, REG_SERIAL_BYTE_4_0_IC_1_BYTE, R47_SERIAL_BYTE_4_0_IC_1_Default );
	if(err != SUCCESS)	rt_kprintf("41\r\n");
	err	= adau1452_write_bytes( DEVICE_ADDR_IC_1, REG_SERIAL_BYTE_5_0_IC_1_ADDR, REG_SERIAL_BYTE_5_0_IC_1_BYTE, R48_SERIAL_BYTE_5_0_IC_1_Default );
	if(err != SUCCESS)	rt_kprintf("42\r\n");
	err	= adau1452_write_bytes( DEVICE_ADDR_IC_1, REG_SERIAL_BYTE_6_0_IC_1_ADDR, REG_SERIAL_BYTE_6_0_IC_1_BYTE, R49_SERIAL_BYTE_6_0_IC_1_Default );
	if(err != SUCCESS)	rt_kprintf("43\r\n");
	err	= adau1452_write_bytes( DEVICE_ADDR_IC_1, REG_SERIAL_BYTE_7_0_IC_1_ADDR, REG_SERIAL_BYTE_7_0_IC_1_BYTE, R50_SERIAL_BYTE_7_0_IC_1_Default );
	if(err != SUCCESS)	rt_kprintf("44\r\n");
	err	= adau1452_write_bytes( DEVICE_ADDR_IC_1, PROGRAM_ADDR_IC_1, PROGRAM_SIZE_IC_1, Program_Data_IC_1 );
	if(err != SUCCESS)	rt_kprintf("45\r\n");
	err	= adau1452_write_bytes( DEVICE_ADDR_IC_1, PARAM_ADDR_IC_1, PARAM_SIZE_IC_1, Param_Data_IC_1 );
	if(err != SUCCESS)	rt_kprintf("46\r\n");
	err	= adau1452_write_bytes( DEVICE_ADDR_IC_1, DM1_DATA_ADDR_IC_1, DM1_DATA_SIZE_IC_1, DM1_DATA_Data_IC_1 );
	if(err != SUCCESS)	rt_kprintf("47\r\n");
	err	= adau1452_write_bytes( DEVICE_ADDR_IC_1, REG_KILL_CORE_IC_1_ADDR, REG_KILL_CORE_IC_1_BYTE, R54_KILL_CORE_IC_1_Default );
	if(err != SUCCESS)	rt_kprintf("48\r\n");
	err	= adau1452_write_bytes( DEVICE_ADDR_IC_1, REG_START_ADDRESS_IC_1_ADDR, REG_START_ADDRESS_IC_1_BYTE, R55_START_ADDRESS_IC_1_Default );
	if(err != SUCCESS)	rt_kprintf("49\r\n");
	err	= adau1452_write_bytes( DEVICE_ADDR_IC_1, REG_START_PULSE_IC_1_ADDR, REG_START_PULSE_IC_1_BYTE, R56_START_PULSE_IC_1_Default );
	if(err != SUCCESS)	rt_kprintf("50\r\n");
	err	= adau1452_write_bytes( DEVICE_ADDR_IC_1, REG_START_CORE_IC_1_ADDR, REG_START_CORE_IC_1_BYTE, R57_START_CORE_IC_1_Default );
	if(err != SUCCESS)	rt_kprintf("51\r\n");
	err	= adau1452_write_bytes( DEVICE_ADDR_IC_1, REG_START_CORE_IC_1_ADDR, REG_START_CORE_IC_1_BYTE, R58_START_CORE_IC_1_Default );
	if(err != SUCCESS)	rt_kprintf("52\r\n");
	err	= adau1452_write_bytes( DEVICE_ADDR_IC_1, REG_HIBERNATE_IC_1_ADDR, REG_HIBERNATE_IC_1_BYTE, R60_HIBERNATE_IC_1_Default );
	if(err != SUCCESS)	rt_kprintf("53\r\n");
}

void i2c_test(void)
{
//	uint8_t buffer[4];
//
//	rt_memset(buffer, 0, 4);
//	if(adau1452_read_bytes(ADAU_DEV_ADDR, LED0_SW, buffer, 4) == SUCCESS)
//		rt_kprintf("read ok.val:0x%02X%02X%02X%02X\r\n", buffer[0], buffer[1], buffer[2], buffer[3]);
//	else
//		rt_kprintf("read err.\r\n");

	uint32_t buffer;
	
	if(adau1452_read_words(ADAU_DEV_ADDR, MOD_SW1_ISON_ADDR, &buffer, 1) == SUCCESS)
		rt_kprintf("read ok.val:0x%08X\r\n", buffer);
	else
		rt_kprintf("read err.\r\n");
}
MSH_CMD_EXPORT(i2c_test, test i2c);

void chart_test(void)
{
	chart chart_struct;

	chart_struct.kk = 0x01;
	dispatch_struct.args = &chart_struct;
	dispatch_struct.notify(&dispatch_struct);
}
MSH_CMD_EXPORT(chart_test, test chart);

void adc_test(void)
{
	mini_device_t adc_dev = RT_NULL;
	adc_ctrl adc_ctrl_struct;

	adc_dev = mini_device_find("adc");
	adc_ctrl_struct.chn_index = 0x01;
	rt_kprintf("rw1 adc:%d\r\n", adc_dev->dops->read(&adc_ctrl_struct, RT_NULL));
}
MSH_CMD_EXPORT(adc_test, test adc);


void timer1_cb(void *para)
{
	mini_device_t led_dev = RT_NULL;
	led_ctrl led_ctrl_struct;
	uint32_t buffer;

	led_dev = mini_device_find("led");
	led_ctrl_struct.led_index = LED0;
	if(led_dev->dops->read(&led_ctrl_struct, RT_NULL) == 0x01)
	{
		led_dev->dops->control(TRUN_ON, &led_ctrl_struct);

		buffer = 0x00000001;
		adau1452_write_words(ADAU_DEV_ADDR, MOD_SW1_ISON_ADDR, &buffer, 1);
//		adau1452_write_bytes(ADAU_DEV_ADDR, LED1_SW, &buffer, 1);
		adau1452_safeload_write_words(ADAU_DEV_ADDR, MOD_SW2_ISON_ADDR, &buffer, 1);
	}
	else
	{
		led_dev->dops->control(TRUN_OFF, &led_ctrl_struct);

		buffer = 0x00000000;

		adau1452_write_words(ADAU_DEV_ADDR, MOD_SW1_ISON_ADDR, &buffer, 1);
//		adau1452_write_bytes(ADAU_DEV_ADDR, LED1_SW, &buffer, 1);
		adau1452_safeload_write_words(ADAU_DEV_ADDR, MOD_SW2_ISON_ADDR, &buffer, 1);
	}	
}

void adau_set(void)//����adauͨ�ŷ�ʽΪi2c
{
	GPIO_InitTypeDef GPIO_InitStructure;
    
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC | RCC_APB2Periph_GPIOB, ENABLE);

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_15;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  	GPIO_Init(GPIOB, &GPIO_InitStructure);

  	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6;
  	GPIO_Init(GPIOC, &GPIO_InitStructure);

  	GPIO_ResetBits(GPIOC, GPIO_Pin_6);
  	GPIO_ResetBits(GPIOB, GPIO_Pin_15);
}

int main(void)
{
	rt_timer_t timer1;

	timer1 = rt_timer_create("timer1", timer1_cb, RT_NULL, 500, RT_TIMER_FLAG_SOFT_TIMER | RT_TIMER_FLAG_PERIODIC);
	if(timer1 != RT_NULL)	rt_timer_start(timer1);

	struct Chart chart;
	Chart_Init(&chart);
	dispatch_struct.add(&dispatch_struct, &chart.parant);

	adau_set();
	bsp_InitI2C();
	if(adau1452_check() == SUCCESS)
	{
		rt_kprintf("check ok.\r\n");
	}
	else
		rt_kprintf("check err.\r\n");
	sigma_default_set();
	while(1)
	{
		mini_device_t led_dev = RT_NULL;
		led_ctrl led_ctrl_struct;
		uint8_t key_code = KEY_NONE;

		key_code = bsp_GetKey();
		if(key_code != KEY_NONE)
		{
			switch(key_code)
			{
				case KEY_1_LONG:
					led_dev = mini_device_find("led");
					led_ctrl_struct.led_index = LED1;
					if(led_dev->dops->read(&led_ctrl_struct, RT_NULL) == 0x01)
						led_dev->dops->control(TRUN_ON, &led_ctrl_struct);
					else
						led_dev->dops->control(TRUN_OFF, &led_ctrl_struct);
				break;
			}
		}
	
		uart_poll_dma_tx(DEV_UART1);
		bsp_KeyScan();
		rt_thread_mdelay(10);
	}
}
