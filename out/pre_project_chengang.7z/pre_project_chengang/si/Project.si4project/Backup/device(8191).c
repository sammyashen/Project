#include "device.h"

struct mini_device *device_list = NULL;

/**
  * @brief  Check whether the device exists.
  * @param  Device handler.
  * @retval true or false.
  */
static bool device_is_exists(mini_device_t *dev )
{
    mini_device_t* cur = device_list;
    while( cur != NULL )
    {
        if( strcmp(cur->name,dev->name)==0)
        {
            return true;
        }
        cur = cur->next;
    }
    return false;
}

/**
  * @brief  Insert device linked list.
  * @param  Device handler.
  * @retval true or false.
  */
static bool device_list_inster(mini_device_t *dev)
{
    mini_device_t *cur = device_list;
    if(NULL == device_list)
    {
        device_list = dev;
        dev->next   = NULL;
    }
    else
    {
        while(NULL != cur->next)
        {
            cur = cur->next;
        }
        cur->next = dev;
        dev->next = NULL;
    }

    return true;
}

/**
  * @brief  Device register.
  * @param  Device handler.
  * @retval true or false.
  */
bool mini_device_register(mini_device_t *dev)
{
    if((NULL == dev) || (device_is_exists(dev)))
    {
        return false;
    }

    if((NULL == dev->name) ||  (NULL == dev->dops))
    {
        return false;
    }
    return device_list_inster(dev);

}

/**
  * @brief  Fine device.
  * @param  Device name.
  * @retval Device handler.
  */
mini_device_t *mini_device_find(const char *name)
{
    mini_device_t* cur = device_list;
    while( cur != NULL )
    {
        if( strcmp(cur->name,name)==0)
        {
            return cur;
        }
        cur = cur->next;
    }
    return NULL;
}


