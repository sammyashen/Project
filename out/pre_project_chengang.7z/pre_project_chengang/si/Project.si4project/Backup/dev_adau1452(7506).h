#ifndef _DEV_ADAU1452_H_
#define _DEV_ADAU1452_H_

#include "stm32f10x.h"
#include "init.h"
#include "device.h"
#include "drv_i2c.h"
#include "rtthread.h"

#define ADAU_DEV_ADDR			0x70

ErrorStatus adau1452_check(void);
ErrorStatus adau1452_read_bytes(uint16_t dev_addr, uint16_t reg_addr, uint32_t *buffer, uint8_t dat_len);
ErrorStatus adau1452_write_bytes(uint16_t dev_addr, uint16_t reg_addr, uint32_t *buffer, uint8_t dat_len);
ErrorStatus adau1452_safeload_write_bytes(uint16_t dev_addr, uint16_t reg_addr, uint32_t *buffer, uint8_t dat_len);


#endif



