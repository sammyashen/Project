#ifndef _DEV_ADAU1452_H_
#define _DEV_ADAU1452_H_

#include "stm32f10x.h"
#include "init.h"
#include "device.h"
#include "drv_i2c.h"
#include "rtthread.h"

typedef uint8_t ADI_REG_TYPE;

#define ADAU_DEV_ADDR			0x70

ErrorStatus adau1452_check(void);
ErrorStatus adau1452_read_words(uint16_t dev_addr, uint16_t reg_addr, uint32_t *buffer, uint8_t dat_len);
ErrorStatus adau1452_write_words(uint16_t dev_addr, uint16_t reg_addr, uint32_t *buffer, uint8_t dat_len);
ErrorStatus adau1452_safeload_write_words(uint16_t dev_addr, uint16_t reg_addr, uint32_t *buffer, uint8_t dat_len);

ErrorStatus adau1452_read_bytes(uint16_t dev_addr, uint16_t reg_addr, uint16_t dat_len, uint8_t *buffer);
ErrorStatus adau1452_write_bytes(uint16_t dev_addr, uint16_t reg_addr, uint16_t dat_len, uint8_t *buffer);

void SIGMA_WRITE_REGISTER_BLOCK(uint16_t devAddress, uint16_t address, uint16_t length, ADI_REG_TYPE *pData);
void SIGMA_WRITE_DELAY(uint16_t devAddress, uint16_t length, ADI_REG_TYPE *pData );


#endif



